package levelPieces;

import gameEngine.Drawable;
import gameEngine.InteractionResult;
import gameEngine.Player;
/**
 * 
 *  *  * 
 * @author Strydr Silverberg
 * @author Kale Carlson
 *
 * Purpose: defining the Creeper class and it's behaviour
 */
public class Creeper extends GamePiece {

	public static final int DAMAGE = 2;
	private String label = "damages within 2 spaces, kills within 1";
	private int location;
	private char symbol = 'C';
	private boolean interactable = true;
	
	public Creeper(char symbol, String label, int location, boolean interactable) {
		super(symbol, label, location, interactable);
	}
	
	public Creeper() {
	}

	public int getLocation() {
		return location;
	}

	public void setLocation(int setLocation) {
		location = setLocation;
	}
	
	public boolean getInteractable() { 
		return interactable;
	}
	@Override
	public void draw() {
		System.out.print(symbol);
	}
	
	//if creeper is 1 space away from player kill player
	@Override
	public InteractionResult interact(Drawable[] gameBoard, int playerLocation) {
		if (playerLocation == this.getLocation() - 1 || playerLocation == this.getLocation() + 1){
			return InteractionResult.KILL;
		}
		return InteractionResult.NONE;
	}
	
	@Override
	public String toString() {
		return symbol + " - " + label ; 
	}
}
