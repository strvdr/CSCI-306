package publicSafety;
import java.util.Scanner;

/**
 * PublicSafety class
 * Represents an entity that oversees two stations, one city station and one university station.
 * Class's responsibility is to manage stations stations contained within it and maintain information
 * about global badge numbers and their relations.
 * @author Strydr Silverberg
 * @author Kale Carlson
 * @date 1/25/26
 */

public class PublicSafety {
	private Station universityStation;
	private Station cityStation;
	private static int currentBadgeNumber;
	
	// default constructor
	public PublicSafety() {
		super();
	}
	
	//constructor that takes two String parameters, the city station and university station names
	public PublicSafety(String universityStationName, String cityStationName) {
		super();
		this.cityStation = new Station(cityStationName);
		this.universityStation= new Station(universityStationName);	
	}

	// doHire is publicly accessible from the PublicSafety class so it is called from there,
	// calls issueHiringOrders which performs the logic for hiring new detectives at a station.
	// Takes a boolean as a parameter which determines whether we are hiring to a city or university station
	public void doHire(boolean cityOrUniversity) { 
		// true is city hire
		if(cityOrUniversity) {
			issueHiringOrders(this.cityStation);
		} else {	
			issueHiringOrders(this.universityStation);
		}
	}
	
	//helper function for doHire. takes input of a Station and adds a detective to the issued station.
	private void issueHiringOrders(Station stationName) {
		Scanner scanner = new Scanner(System.in);	
		//ensures that we don't add more than 5 detectives to a station
		if(stationName.detectives[4] != null) {
			System.out.println("Can't hire any more detectives for " + stationName.getSTATION_NAME());
			scanner.close();
			return;
		}
		
		System.out.print("New hire for " + stationName.getSTATION_NAME() + "...Enter detective's name: ");
		String newDetectiveName = scanner.nextLine(); 
		//iterates over the detectives list at a given station
		for(int i = 0; i < stationName.detectives.length; i++) { 
			//once we find an empty slot in the detectives list (we already checked for 
			//detective count above), we add the new detective to the station's list
			if(stationName.detectives[i] == null) {
				stationName.detectives[i] = new Detective(newDetectiveName);
				this.currentBadgeNumber += 1;
				stationName.detectives[i].setBadgeNumber(this.currentBadgeNumber);
				break;
			}
		}
		
	}

	public void printDetectiveLists() {
		System.out.println(cityStation);
		System.out.println(universityStation);
	}

	//getCurrentBadgeNumber is only called when we add a detective to a station, and we start at 0
	//so we increment before returning the badge number
	public static int getCurrentBadgeNumber() {
		currentBadgeNumber++;
		return currentBadgeNumber;
	}

}
