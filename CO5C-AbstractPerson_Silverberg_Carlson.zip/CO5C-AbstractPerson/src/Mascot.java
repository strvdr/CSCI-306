/**
 * Mascot class. 
 *  
 * @author Stryder Silverberg
 * @author Kale Carlson
 * 
 * Date: 1/28/2026
 * Purpose: Represents a school's mascot, which is a child of a Person
 */

public class Mascot extends Person{

	//private instance variables that contain information about specific mascot
 	private String mySchool;
	private String mascotType;
	private int questionNumber = 0;
	private int answerNumber = 0;
	private String[] questions;
	private String[] answers;
	
	//Mascot is instantiated with lists of questions and answers to be filled
	//with the values placed in school and animal
	public Mascot(String name, String occupation, String school, String animal) {
		super(name, occupation);
		mySchool = school;
		mascotType = animal;
		
		questions = new String[] {
			"What's your favorite " + mascotType + "?",
			"What school do you go to?",
			"You think you could beat me in an arm wrestling match?",
			"Have you been studying?",
			"How many people do you think wore this suit before me?"
		};
		
		answers = new String[] {
			"You should tour " + mySchool + "!",
			"It's sweaty in this suit",
			"I'm the mascot for " + mySchool + "!",
			"GET ON THE FIELD!",
			"Have you seen the redbull car yet?",
			"I can run a 2 minute mile!"
		};
	}
	
	// Answer question iterates through the array of answers available and goes back to the first answer  
	// after all have been answered 
	public void answerQuestion() {
		System.out.println(answers[answerNumber]);
		answerNumber++;
		if(answerNumber > answers.length){
			answerNumber = 0;
		}
	}
	
	// ask question iterates through the array of questions available and goes back to the first question 
	// after all have been asked 
	public void askQuestion() {	
		System.out.println(questions[questionNumber]);
		questionNumber++;
		if(questionNumber > questions.length){
			questionNumber = 0;
		}
	}
	
	//Overrides the parent class's whatIDo method. Instead of using the default implementation, 
	// completely makes it's own "whatIDo".
	@Override
	public void whatIDo() {
		System.out.println("I do some " + this.getOccupation() + " things!");
	}
}
